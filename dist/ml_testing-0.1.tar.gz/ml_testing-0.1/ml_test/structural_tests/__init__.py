from .structural_tests import StructuralData

__all__ =["StructuralData"]
