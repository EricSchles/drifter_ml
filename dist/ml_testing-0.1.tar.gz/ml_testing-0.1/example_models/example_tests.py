from ml_test import classification_tests
import joblib
import pandas as pd
import code

df = pd.read_csv("data.csv")
column_names = ["A", "B", "C"]
target_name = "target"
clf = joblib.load("model1.joblib")

test_suite = classification_tests.ClassificationTests(clf,
                                                      df,
                                                      target_name,
                                                      column_names, '', '')
code.interact(local=locals())
print(test_suite.precision_lower_boundary_per_class(
    {column: 0.9 for column in column_names}
))
